import React from "react";

function Info(){
  return(
    <div className="note">
      <h1>Javascript and React.js</h1>
      <p>A Basic Web Dev React JS Bootcamp.And this is the amazing Bootcamp ever I seen.And also I thanks to ShapeAI to conduct such as wonderful Bootcamp with free of cost...</p>
    </div>
  );
}

export default Info;